package com.example.damdinhdinh.taskreminder;

import android.content.Context;
import android.view.View;

public interface ShowPopup {
    void showPopupMenu(Context context, View view, final int i);
}
